
package makuyacontrolroomserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;

public class MakuyaControlRoomServer extends JFrame{

   int guardAction;

   
   public static void main(String []args){ 
   
   JFrame frame = new JFrame("Select a Option");
   JButton yes = new JButton("Yes");
   JButton no =  new JButton("No");
   JButton cancel = new JButton("Cancel");
   
  
  frame.setSize(300, 200);
  frame.setTitle("Select a Option");
  frame.setVisible(true);
  
  
            
        try {
            ServerSocket server = new ServerSocket(4321);
            System.out.println("address = Symphony way 123");
            Socket Home = server.accept();
            System.out.println("Guard on his way");
            
            DataInputStream input = new DataInputStream(Home.getInputStream());
            DataOutputStream output =  new DataOutputStream(Home.getOutputStream());
            
            String clientType = input.readUTF();
            System.out.println("Guard arrived");
            System.out.println("Send Backup");
            System.out.println("House is safe");
            
            output.writeUTF("Security Said : I also got you bro\n");
            Home.close();
            
        } catch (IOException ex) {
            Logger.getLogger(MakuyaControlRoomServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
