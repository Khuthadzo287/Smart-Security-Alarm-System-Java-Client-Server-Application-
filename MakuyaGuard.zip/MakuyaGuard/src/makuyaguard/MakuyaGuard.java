
package makuyaguard;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;


public class MakuyaGuard extends Application{
 @Override
    public void start(Stage stage) throws Exception {
        FlowPane layout = new FlowPane();
        Label label =  new Label("Symphony way 123");
        Button onmyWay = new Button("On my way");
        
        layout.getChildren().add(onmyWay);
        layout.getChildren().addAll( label);
        
        Scene scene =  new Scene(layout, 300,200);
        stage.setScene(scene);
        stage.setTitle("Guard");
        stage.show();
        
        onmyWay.setOnAction(e -> {
            
        });
        
    }
    
    public static void main(String[] args) {
        launch(args);
        
     try {
         Socket guard =  new Socket("localhost", 4321);
         DataOutputStream output =  new DataOutputStream(guard.getOutputStream());
         output.writeUTF("hello");
         System.out.println("");
  
     } catch (IOException ex) {
         Logger.getLogger(MakuyaGuard.class.getName()).log(Level.SEVERE, null, ex);
     }
      
    
}
}