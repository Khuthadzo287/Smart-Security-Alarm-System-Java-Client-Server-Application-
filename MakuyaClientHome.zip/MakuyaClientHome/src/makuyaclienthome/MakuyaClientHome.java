
package makuyaclienthome;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;


public class MakuyaClientHome extends Application {

    
    @Override
    public void start(Stage stage) throws Exception {
     FlowPane layout = new FlowPane();
    
     Button alarm = new Button("Alarm");
     Button move = new Button("Move");
     Button one = new Button("1");
     Button two = new Button("2");
     Button three = new Button("3");
     TextField textfield = new TextField();
     
     layout.getChildren().add(alarm);
     layout.getChildren().add(move);
     layout.getChildren().add(one);
     layout.getChildren().add(two);
     layout.getChildren().add(three);
     layout.getChildren().addAll(textfield);
     
     Scene scene = new Scene(layout, 300,200);
     stage.setScene(scene);
     stage.setTitle("Home Alarm");
     stage.show();
     
     textfield.layout();
     alarm.setOnAction( e -> {
         System.out.println("alarm");
         textfield.appendText("Alarm Pressed" + alarm);
     });
     
     move.setOnAction(e -> {
         System.out.println("move");
     });
     
     one.setOnAction(e ->{
         System.out.println("1");
     });
     two.setOnAction( e -> {
         System.out.println("2");
     });
     three.setOnAction(e -> {
         System.out.println("3");
         
     });
     
     
    }
    

    
    
   
    public static void main(String[] args) {
        try {
            Socket Home = new Socket("localhost", 4321);
            
            DataOutputStream output =  new DataOutputStream(Home.getOutputStream());
            DataInputStream input = new DataInputStream(Home.getInputStream());
            
            output.writeUTF("Home");
            System.out.println(" Hello security there is a thief ");
            String clientType = input.readUTF();
            System.out.println("Hello Security I received Action \n" + clientType);
            
            
            Home.close();
        } catch (IOException ex) {
            Logger.getLogger(MakuyaClientHome.class.getName()).log(Level.SEVERE, null, ex);
        }
        launch(args);
    }
}
    
